# splitting

A Pen created on CodePen.io. Original URL: [https://codepen.io/Ha-euisook/pen/WNLmyVP](https://codepen.io/Ha-euisook/pen/WNLmyVP).

