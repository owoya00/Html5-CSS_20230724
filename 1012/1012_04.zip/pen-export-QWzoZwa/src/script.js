gsap.to(".left",{x:100,duration:1})
gsap.to(".right",{x:200,duration:2},1.5)